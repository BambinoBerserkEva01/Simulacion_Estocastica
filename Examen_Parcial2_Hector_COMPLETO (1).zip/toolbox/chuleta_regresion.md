
# 📘 Chuleta de Código – Análisis de Regresión
### Héctor Madera – Toolbox para exámenes

---

## ⚙️ Setup Rápido

```python
from modelo_regresion_toolbox import analizar_modelo
analizar_modelo(X, Y)
```

---

## 🔢 Regresión Lineal

```python
from practica_1_0 import regresion_lineal_simple
regresion_lineal_simple(X, Y)
```

---

## ✅ Validar Modelo

```python
from practica_2_2 import evaluar_significancia
from practica_3_3 import validar_supuestos
```

---

## 🔁 Selección de Variables

```python
from seleccion_variables import forward_selection, backward_elimination
```

---

## 📈 Modelos Especiales

```python
from practica_3_5 import ajustar_modelo_polinomial
from practica_3_6 import modelo_no_lineal_mantenimiento
from practica_3_7 import ajustar_modelo_exponencial
from practica_3_8 import ajustar_modelo_logaritmico
```

---

## 🧪 Colinealidad

```python
from diagnostico_colinealidad import calcular_vif, matriz_correlacion
```

---

## 📊 Clasificación

```python
from modelo_logit_probit import ajustar_logit, ajustar_probit
from evaluacion_clasificacion import evaluar_clasificacion
```

---

## 📉 Series Temporales

```python
from modelo_arima import ajustar_arima
from modelo_poisson import ajustar_poisson
```

---

## 🔄 Comparación de Modelos

```python
from comparacion_modelos import comparar_modelos
```

---

## 📌 Comandos comunes para estandarizar y cargar datos:

```python
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
Z = scaler.fit_transform(X)

import pandas as pd
df = pd.read_csv("archivo.csv")
X = df.iloc[:, :-1].values
Y = df.iloc[:, -1].values
```

---

## 💡 Al final: Archivo → Imprimir → Guardar como PDF
