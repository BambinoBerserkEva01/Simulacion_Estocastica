
"""
Modelos Logit y Probit - Clasificación Binaria

Ajuste de modelos para variables de respuesta binaria usando statsmodels.

Autor: Héctor Madera
"""

import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt

def ajustar_logit(X, y, verbose=True):
    """
    Ajusta un modelo Logit (logística binaria)

    Args:
        X (ndarray): Matriz de predictores
        y (ndarray): Vector binario de salida (0/1)
        verbose (bool): Mostrar resumen y curva

    Returns:
        modelo ajustado
    """
    X_const = sm.add_constant(X)
    modelo = sm.Logit(y, X_const).fit(disp=False)

    if verbose:
        print("Modelo Logit")
        print(modelo.summary())

    return modelo

def ajustar_probit(X, y, verbose=True):
    """
    Ajusta un modelo Probit (distribución normal acumulada)

    Args:
        X (ndarray): Matriz de predictores
        y (ndarray): Vector binario de salida (0/1)
        verbose (bool): Mostrar resumen y curva

    Returns:
        modelo ajustado
    """
    X_const = sm.add_constant(X)
    modelo = sm.Probit(y, X_const).fit(disp=False)

    if verbose:
        print("Modelo Probit")
        print(modelo.summary())

    return modelo
