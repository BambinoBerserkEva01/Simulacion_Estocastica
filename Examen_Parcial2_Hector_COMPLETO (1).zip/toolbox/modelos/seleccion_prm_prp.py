
"""
Selección por Relevancia (PRM) y Perjuicio (PRP)

Algoritmos heurísticos para elegir variables por su impacto positivo o negativo.

Autor: Héctor Madera
"""

import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score

def seleccion_prm(X, y, nombres=None, verbose=True):
    """Selecciona el predictor más relevante (PRM)"""
    m = X.shape[1]
    nombres = nombres or [f"X{i+1}" for i in range(m)]

    scores = []
    for i in range(m):
        modelo = LinearRegression().fit(X[:, [i]], y)
        r2 = r2_score(y, modelo.predict(X[:, [i]]))
        scores.append((i, r2))

    scores.sort(key=lambda x: x[1], reverse=True)

    if verbose:
        for i, r2 in scores:
            print(f"{nombres[i]}: R² = {r2:.4f}")

    return scores[0][0]

def seleccion_prp(X, y, nombres=None, verbose=True):
    """Elimina el predictor menos perjudicial (PRP)"""
    m = X.shape[1]
    nombres = nombres or [f"X{i+1}" for i in range(m)]

    modelo_completo = LinearRegression().fit(X, y)
    r2_completo = r2_score(y, modelo_completo.predict(X))

    impacto = []
    for i in range(m):
        X_temp = np.delete(X, i, axis=1)
        r2_temp = r2_score(y, LinearRegression().fit(X_temp, y).predict(X_temp))
        delta = r2_completo - r2_temp
        impacto.append((i, delta))

    impacto.sort(key=lambda x: x[1])

    if verbose:
        for i, d in impacto:
            print(f"{nombres[i]}: ΔR² = {d:.4f}")

    return impacto[0][0]
