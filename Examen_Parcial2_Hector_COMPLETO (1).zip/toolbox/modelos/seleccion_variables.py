
"""
Métodos de Selección de Variables:
- Forward Selection
- Backward Elimination

Autor: Héctor Madera
"""

import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
import statsmodels.api as sm

def forward_selection(X, y, nombres_vars=None, verbose=True):
    n, m = X.shape
    disponibles = list(range(m))
    seleccionadas = []
    mejor_r2 = 0

    nombres_vars = nombres_vars or [f"X{i+1}" for i in range(m)]

    while disponibles:
        mejor_score = mejor_r2
        mejor_variable = None

        for i in disponibles:
            candidatos = seleccionadas + [i]
            modelo = LinearRegression().fit(X[:, candidatos], y)
            r2 = r2_score(y, modelo.predict(X[:, candidatos]))
            if r2 > mejor_score:
                mejor_score = r2
                mejor_variable = i

        if mejor_variable is not None:
            seleccionadas.append(mejor_variable)
            disponibles.remove(mejor_variable)
            mejor_r2 = mejor_score
            if verbose:
                print(f"Seleccionada: {nombres_vars[mejor_variable]} - R²: {mejor_r2:.4f}")
        else:
            break

    return seleccionadas

def backward_elimination(X, y, threshold=0.05, nombres_vars=None, verbose=True):
    X_model = X.copy()
    vars_idx = list(range(X.shape[1]))
    nombres = nombres_vars or [f"X{i+1}" for i in vars_idx]

    while True:
        X_const = sm.add_constant(X_model)
        modelo = sm.OLS(y, X_const).fit()
        pvals = modelo.pvalues[1:]

        if len(pvals) == 0 or pvals.max() <= threshold:
            break

        idx_max = int(np.argmax(pvals))
        if verbose:
            print(f"Eliminando {nombres[vars_idx[idx_max]]} (p = {pvals[idx_max]:.4f})")
        del nombres[vars_idx[idx_max]]
        del vars_idx[idx_max]
        X_model = X[:, vars_idx]

    if verbose:
        print(modelo.summary())
    return vars_idx
