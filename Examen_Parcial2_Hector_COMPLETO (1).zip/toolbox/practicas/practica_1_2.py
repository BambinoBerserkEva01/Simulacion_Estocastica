
"""
Práctica 1.2 - Estimación de parámetros B0 y B1

Esta práctica visualiza la distribución de estimaciones de parámetros de regresión
(B0 y B1) usando histogramas y curvas KDE.

Autor: Rodriguez Garcia Emiliano
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Estimaciones simuladas de los parámetros B0 y B1
b0 = np.array([54.4318, 45.9125, 41.5865, 53.3747, 45.4150, 50.6884, 51.0554, 54.0890, 49.3757, 41.7093,
               44.1496, 46.5329, 47.9720, 50.0111, 49.3293, 47.2061, 47.5955, 44.3369, 49.5155, 59.4409, 57.1467])

b1 = np.array([-2.1164, -1.7870, -1.7554, -2.0865, -1.9854, -1.9962, -1.9356, -2.1401, -1.9619, -1.8015,
               -1.8641, -1.8550, -1.9955, -1.9608, -2.0154, -1.9450, -1.8661, -1.8670, -1.9925, -2.2607, -2.1469])

def graficar_distribuciones():
    """
    Muestra histogramas con curvas KDE de los parámetros b0 y b1.
    """
    plt.figure(figsize=(12, 6))

    # Histograma y KDE de b0
    plt.subplot(1, 2, 1)
    plt.hist(b0, bins=5, edgecolor='black', color='green', density=True)
    sns.kdeplot(b0, color='black', lw=2)
    plt.title('Histograma y KDE de b0')
    plt.xlabel('b0')
    plt.ylabel('Densidad')

    # Histograma y KDE de b1
    plt.subplot(1, 2, 2)
    plt.hist(b1, bins=5, edgecolor='black', color='blue', density=True)
    sns.kdeplot(b1, color='red', lw=2)
    plt.title('Histograma y KDE de b1')
    plt.xlabel('b1')
    plt.ylabel('Densidad')

    plt.tight_layout()
    plt.show()
