
"""
Práctica 2.4 - Eliminación hacia atrás vs R²

Compara dos enfoques para selección de variables en regresión:
1. Eliminación hacia atrás basada en p-valores (con statsmodels)
2. Selección basada en maximizar el R²

Autor: Rodriguez Garcia Emiliano
"""

import numpy as np
import statsmodels.api as sm
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score

def eliminacion_hacia_atras(X, y, threshold=0.05, nombres_vars=None):
    """
    Realiza eliminación hacia atrás eliminando variables con mayor p-valor.

    Args:
        X (ndarray): Matriz de predictores.
        y (ndarray): Variable dependiente.
        threshold (float): Umbral de significancia.
        nombres_vars (list): Lista opcional de nombres de variables.

    Returns:
        model: Modelo ajustado final.
    """
    X_model = X.copy()
    vars_idx = list(range(X.shape[1]))
    nombres = nombres_vars if nombres_vars else [f"X{i+1}" for i in vars_idx]

    while True:
        X_const = sm.add_constant(X_model)
        modelo = sm.OLS(y, X_const).fit()
        pvals = modelo.pvalues[1:]  # ignorar el intercepto

        if pvals.max() > threshold:
            idx_max = pvals.argmax()
            removed_var = nombres[vars_idx[idx_max]]
            if removed_var:
                print(f"Eliminando {removed_var} (p = {pvals[idx_max]:.4f})")
            del nombres[vars_idx[idx_max]]
            del vars_idx[idx_max]
            X_model = X[:, vars_idx]
        else:
            break

    print(modelo.summary())
    return modelo

def modelo_por_r2(X, y, nombres_vars=None):
    """
    Selección de variables con base en R² (Forward Selection).

    Args:
        X (ndarray): Matriz de predictores.
        y (ndarray): Variable dependiente.
        nombres_vars (list): Lista de nombres opcionales.

    Returns:
        list: Índices seleccionados
    """
    n, m = X.shape
    disponibles = list(range(m))
    seleccionadas = []
    mejor_r2 = 0

    if nombres_vars is None:
        nombres_vars = [f"X{i+1}" for i in range(m)]

    while disponibles:
        mejor_score = mejor_r2
        mejor_variable = None

        for i in disponibles:
            candidatos = seleccionadas + [i]
            modelo = LinearRegression().fit(X[:, candidatos], y)
            r2 = r2_score(y, modelo.predict(X[:, candidatos]))
            if r2 > mejor_score:
                mejor_score = r2
                mejor_variable = i

        if mejor_variable is not None:
            seleccionadas.append(mejor_variable)
            disponibles.remove(mejor_variable)
            mejor_r2 = mejor_score
            print(f"Seleccionada: {nombres_vars[mejor_variable]} - R²: {mejor_r2:.4f}")
        else:
            break

    return seleccionadas
