
"""
Práctica 2.5 - Selección hacia atrás (Backward Elimination)

Implementa el algoritmo de eliminación hacia atrás basado en p-valores, removiendo
iterativamente las variables menos significativas.

Autor: Rodriguez Garcia Emiliano
"""

import numpy as np
import statsmodels.api as sm

def seleccion_hacia_atras(X, y, threshold=0.05, nombres_vars=None):
    """
    Realiza selección hacia atrás eliminando variables con p-valores > threshold.

    Args:
        X (ndarray): Matriz de predictores (n muestras x m variables).
        y (ndarray): Vector objetivo.
        threshold (float): Umbral de significancia (default 0.05).
        nombres_vars (list): Lista opcional de nombres de variables.

    Returns:
        model: Modelo final ajustado con statsmodels.
    """
    X_model = X.copy()
    variables = list(range(X.shape[1]))
    nombres = nombres_vars or [f"X{i+1}" for i in variables]

    while True:
        X_const = sm.add_constant(X_model)
        modelo = sm.OLS(y, X_const).fit()
        pvals = modelo.pvalues[1:]  # ignorar intercepto

        if len(pvals) == 0 or pvals.max() <= threshold:
            break

        idx_max = int(np.argmax(pvals))
        removed = nombres[variables[idx_max]]
        print(f"Eliminando {removed} (p = {pvals[idx_max]:.4f})")
        del nombres[variables[idx_max]]
        del variables[idx_max]
        X_model = X[:, variables]

    print(modelo.summary())
    return modelo
