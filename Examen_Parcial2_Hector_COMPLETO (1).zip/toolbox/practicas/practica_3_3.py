
"""
Práctica 3.3 - Homocedasticidad e Intervalos de Confianza

Evalúa la homocedasticidad mediante gráficos de residuos y calcula intervalos de confianza para los coeficientes.

Autor: Rodriguez Garcia Emiliano
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
from numpy.linalg import inv

def analizar_homocedasticidad_y_confianza(X, Y, alpha=0.05):
    """
    Ajusta regresión lineal, grafica residuos, y calcula intervalos de confianza.

    Args:
        X (ndarray): Matriz de predictores (n x m)
        Y (ndarray): Vector de respuesta (n)
        alpha (float): Nivel de significancia (default 0.05 para 95% IC)

    Returns:
        dict: {'coeficientes', 'ICs', 'residuos'}
    """
    n, m = X.shape
    X_aug = np.column_stack([np.ones(n), X])
    beta = inv(X_aug.T @ X_aug) @ X_aug.T @ Y
    y_pred = X_aug @ beta
    e = Y - y_pred
    MSres = np.sum(e**2) / (n - m - 1)

    var_b = MSres * inv(X_aug.T @ X_aug)
    se = np.sqrt(np.diag(var_b))

    t_val = stats.t.ppf(1 - alpha / 2, df=n - m - 1)
    ICs = [(beta[i] - t_val * se[i], beta[i] + t_val * se[i]) for i in range(len(beta))]

    print("Intervalos de Confianza al 95%:")
    for i, (b, ic) in enumerate(zip(beta, ICs)):
        var_name = "Intercepto" if i == 0 else f"X{i}"
        print(f"{var_name}: {b:.4f} ∈ [{ic[0]:.4f}, {ic[1]:.4f}]")

    # Gráficos de residuos vs predictores
    fig, axs = plt.subplots(1, m, figsize=(5 * m, 4))
    if m == 1:
        axs = [axs]
    for i in range(m):
        axs[i].scatter(X[:, i], e)
        axs[i].axhline(0, color='gray', linestyle='--')
        axs[i].set_title(f"Residuales vs X{i+1}")
        axs[i].set_xlabel(f"X{i+1}")
        axs[i].set_ylabel("Residuales")
    plt.tight_layout()
    plt.show()

    return {"coeficientes": beta, "ICs": ICs, "residuos": e}
