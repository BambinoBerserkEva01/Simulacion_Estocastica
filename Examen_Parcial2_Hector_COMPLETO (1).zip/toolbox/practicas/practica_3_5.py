
"""
Práctica 3.5 - Modelo de Regresión Polinomial

Ajusta un modelo de regresión polinomial y muestra sus coeficientes.
Útil para capturar relaciones no lineales entre X y Y.

Autor: Rodriguez Garcia Emiliano
"""

import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures

def ajustar_modelo_polinomial(X, y, grado=4, graficar=False):
    """
    Ajusta un modelo de regresión polinomial a los datos.

    Args:
        X (ndarray): Variable independiente (n muestras x 1 variable).
        y (ndarray): Variable dependiente.
        grado (int): Grado del polinomio.
        graficar (bool): Si True y X tiene una sola columna, grafica el ajuste.

    Returns:
        modelo (LinearRegression): Modelo entrenado
    """
    poly = PolynomialFeatures(degree=grado, include_bias=False)
    X_poly = poly.fit_transform(X)

    modelo = LinearRegression()
    modelo.fit(X_poly, y)

    print("Coeficientes:")
    for i, coef in enumerate([modelo.intercept_, *modelo.coef_]):
        print(f"β{i} = {coef:.4f}")

    if graficar and X.shape[1] == 1:
        x_range = np.linspace(X.min(), X.max(), 200).reshape(-1, 1)
        x_range_poly = poly.transform(x_range)
        y_pred = modelo.predict(x_range_poly)

        plt.scatter(X, y, label='Datos')
        plt.plot(x_range, y_pred, color='red', label='Ajuste polinomial')
        plt.title(f'Regresión Polinomial (grado {grado})')
        plt.xlabel('X')
        plt.ylabel('Y')
        plt.legend()
        plt.grid(True)
        plt.show()

    return modelo
