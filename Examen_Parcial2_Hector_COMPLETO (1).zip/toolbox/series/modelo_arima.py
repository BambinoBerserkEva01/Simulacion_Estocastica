
"""
Modelo ARIMA para Series Temporales

Ajusta un modelo ARIMA(p,d,q) con predicción simple.

Autor: Héctor Madera
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.stattools import adfuller

def ajustar_arima(serie, orden=(1, 1, 1), pasos=10, verbose=True):
    """
    Ajusta un modelo ARIMA y realiza predicción.

    Args:
        serie (array-like): Serie temporal
        orden (tuple): Parámetros (p, d, q)
        pasos (int): Pasos a predecir
        verbose (bool): Mostrar resultado y gráfica

    Returns:
        dict: modelo, predicción
    """
    serie = pd.Series(serie).dropna()

    resultado_adf = adfuller(serie)
    if verbose:
        print(f"ADF Test: p-value = {resultado_adf[1]:.4f}")

    modelo = ARIMA(serie, order=orden).fit()

    pred = modelo.forecast(steps=pasos)

    if verbose:
        print(modelo.summary())
        plt.plot(serie, label="Serie original")
        plt.plot(range(len(serie), len(serie) + pasos), pred, label="Pronóstico", linestyle="--")
        plt.legend()
        plt.title("ARIMA")
        plt.grid(True)
        plt.show()

    return {
        "modelo": modelo,
        "prediccion": pred
    }
