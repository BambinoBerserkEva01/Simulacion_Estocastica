
"""
Modelo de Regresión de Poisson

Para respuestas de conteo (Y ∈ N) usando GLM y distribución de Poisson.

Autor: Héctor Madera
"""

import numpy as np
import statsmodels.api as sm

def ajustar_poisson(X, y, verbose=True):
    """
    Ajusta un modelo de regresión de Poisson

    Args:
        X (ndarray): Matriz de predictores
        y (ndarray): Vector de respuesta (conteos enteros)
        verbose (bool): Mostrar resumen

    Returns:
        modelo ajustado
    """
    X_const = sm.add_constant(X)
    modelo = sm.GLM(y, X_const, family=sm.families.Poisson()).fit()

    if verbose:
        print("Modelo de Poisson")
        print(modelo.summary())

    return modelo
