
# 🧠 Caja de Herramientas de Regresión Lineal
### Autor: Héctor Madera

Este repositorio contiene prácticas estructuradas y código modular para aplicar modelos de regresión lineal, múltiples, polinomiales, categóricos y no lineales, incluyendo validación de supuestos y selección de variables.

---

## 📁 Estructura del Proyecto

```
regresion_toolbox/
├── practicas/                  # Código modular por práctica
│   ├── practica_1_0.py         # Regresión lineal simple
│   ├── practica_2_1.py         # Regresión múltiple
│   ├── practica_2_2.py         # Significancia del modelo
│   └── ...
├── toolbox/
│   └── modelo_regresion_toolbox.py  # Código maestro automatizado
├── README.md
├── requirements.txt
└── plantilla_colab.ipynb       # Plantilla para resolver exámenes en Colab
```

---

## 🚀 Cómo usar

### En Google Colab
1. Sube los archivos `.py` necesarios o monta Drive.
2. Usa la plantilla `plantilla_colab.ipynb` como punto de partida.

### En VS Code
1. Crea entorno virtual: `python -m venv venv`
2. Activa: `venv\Scripts\activate` (Windows) o `source venv/bin/activate` (Mac/Linux)
3. Instala dependencias: `pip install -r requirements.txt`

---

## 📚 Prácticas cubiertas

- Regresión lineal simple
- Regresión lineal múltiple
- Significancia estadística (F-test y t-test)
- Selección de variables (hacia delante y hacia atrás)
- Regresión con variables categóricas
- Modelos polinómicos, exponenciales, logarítmicos y no lineales
- Verificación de supuestos del modelo: residuos, homocedasticidad, normalidad

---

## 🧪 Función maestra de análisis

```python
from modelo_regresion_toolbox import analizar_modelo
resultado = analizar_modelo(X, Y)
```

Incluye:
- Ajuste de modelo
- p-valores individuales y globales
- Intervalos de confianza
- Gráficas de residuos y QQ-plot

---

## ✍️ Autor

> Héctor Madera  
> Proyecto final de curso — Regresión Lineal

