
"""
Intervalos de Predicción para Nuevas Observaciones

Calcula el intervalo de confianza de la media de Y dado un nuevo vector X.

Autor: Héctor Madera
"""

import numpy as np
from scipy.stats import t
from numpy.linalg import inv

def intervalo_confianza_prediccion(X_train, Y_train, X_nuevo, alpha=0.05):
    """
    Calcula intervalo de confianza para predicción puntual.

    Args:
        X_train (ndarray): Matriz de entrenamiento (n x m)
        Y_train (ndarray): Vector de respuesta
        X_nuevo (ndarray): Vector de predictores (1 x m)
        alpha (float): Nivel de significancia

    Returns:
        dict: valor predicho, intervalo (min, max)
    """
    n, m = X_train.shape
    X_aug = np.column_stack([np.ones(n), X_train])
    X0 = np.insert(X_nuevo, 0, 1).reshape(1, -1)

    beta = inv(X_aug.T @ X_aug) @ X_aug.T @ Y_train
    y_hat = float(X0 @ beta)
    resid = Y_train - X_aug @ beta
    s2 = np.sum(resid**2) / (n - m - 1)
    var_pred = s2 * (X0 @ inv(X_aug.T @ X_aug) @ X0.T)

    t_val = t.ppf(1 - alpha / 2, n - m - 1)
    error_margin = t_val * np.sqrt(var_pred)
    return {
        "prediccion": y_hat,
        "IC": (y_hat - error_margin, y_hat + error_margin)
    }
