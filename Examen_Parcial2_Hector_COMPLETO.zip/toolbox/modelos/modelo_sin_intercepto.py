
"""
Regresión Lineal Múltiple sin Intercepto

Este módulo ajusta un modelo de regresión lineal forzado al origen (β0 = 0).

Autor: Héctor Madera
"""

import numpy as np
import statsmodels.api as sm
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
import matplotlib.pyplot as plt

def ajustar_sin_intercepto(X, Y, verbose=True):
    """
    Ajusta un modelo de regresión lineal múltiple sin intercepto.

    Args:
        X (ndarray): Matriz de predictores (n x m)
        Y (ndarray): Vector de respuesta (n,)
        verbose (bool): Si True, imprime resumen y gráfica

    Returns:
        dict: coeficientes, R², modelo OLS
    """
    modelo = LinearRegression(fit_intercept=False)
    modelo.fit(X, Y)
    y_pred = modelo.predict(X)

    X_ols = X  # sin agregar constante
    modelo_ols = sm.OLS(Y, X_ols).fit()

    if verbose:
        print("Coeficientes:", modelo.coef_)
        print(f"R²: {r2_score(Y, y_pred):.4f}")
        print(modelo_ols.summary())

        plt.scatter(Y, y_pred)
        plt.plot(Y, Y, color='red', linestyle='--')
        plt.xlabel("Y Real")
        plt.ylabel("Y Predicho")
        plt.title("Regresión sin Intercepto")
        plt.grid(True)
        plt.show()

    return {
        "coeficientes": modelo.coef_,
        "r2": r2_score(Y, y_pred),
        "modelo": modelo_ols
    }
