
"""
Práctica 1.0 - Regresión Lineal Simple

Ajuste de un modelo lineal simple: Y = β0 + β1 * X.
Incluye visualización, R² y análisis del modelo.

Autor: Rodriguez Garcia Emiliano
"""

import numpy as np
import matplotlib.pyplot as plt
import statsmodels.api as sm
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score

def regresion_lineal_simple(X, Y):
    """
    Ajusta un modelo de regresión lineal simple y visualiza resultados.

    Args:
        X (ndarray): Variable independiente (n,).
        Y (ndarray): Variable dependiente (n,).

    Returns:
        dict: Coeficientes, R², modelo statsmodels
    """
    X = X.reshape(-1, 1)  # asegurarse de que sea 2D
    model = LinearRegression()
    model.fit(X, Y)
    y_pred = model.predict(X)

    # Visualización
    plt.scatter(X, Y, label='Datos')
    plt.plot(X, y_pred, color='red', label='Línea de regresión')
    plt.title("Regresión Lineal Simple")
    plt.xlabel("X")
    plt.ylabel("Y")
    plt.legend()
    plt.grid(True)
    plt.show()

    # Ajuste con statsmodels para resumen detallado
    X_sm = sm.add_constant(X)
    model_sm = sm.OLS(Y, X_sm).fit()
    print(model_sm.summary())

    return {
        "intercepto": model.intercept_,
        "coeficiente": model.coef_[0],
        "r2": r2_score(Y, y_pred),
        "modelo": model_sm
    }
