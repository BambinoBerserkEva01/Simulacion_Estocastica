
"""
Práctica 2.2 - Significancia del Modelo y Regresores

Evalúa la calidad del modelo mediante F-test global y pruebas t individuales para cada regresor.

Autor: Rodriguez Garcia Emiliano
"""

import numpy as np
import pandas as pd
from scipy import stats
from numpy.linalg import inv
from math import sqrt

def evaluar_significancia(X, Y):
    """
    Ajusta un modelo de regresión lineal y evalúa la significancia global e individual.

    Args:
        X (ndarray): Matriz de predictores (n x m)
        Y (ndarray): Vector objetivo (n)

    Returns:
        pd.DataFrame: Tabla con regresores y su significancia (p-valor individual)
    """
    n, m = X.shape
    X_aug = np.column_stack([np.ones(n), X])
    beta = inv(X_aug.T @ X_aug) @ X_aug.T @ Y
    y_pred = X_aug @ beta

    SSres = np.sum((Y - y_pred) ** 2)
    SSr = np.sum((y_pred - np.mean(Y)) ** 2)
    MSres = SSres / (n - m - 1)
    MSr = SSr / m
    F0 = MSr / MSres

    print(f"F0 (modelo): {F0:.4f}")
    p_val = stats.f.sf(F0, m, n - m - 1)
    print(f"p-valor del modelo: {p_val:.6f}")
    print(f"Significancia del modelo: {1 - p_val:.6f}")

    # Errores estándar de coeficientes
    var_b = MSres * inv(X_aug.T @ X_aug)
    se = np.sqrt(np.diag(var_b))[1:]  # ignorar constante
    t_vals = np.abs(beta[1:] / se)
    p_vals = 2 * stats.t.sf(t_vals, n - m - 1)  # prueba bilateral

    resultados = pd.DataFrame({
        "Regresor": [f"X{i+1}" for i in range(m)],
        "β": beta[1:],
        "t": t_vals,
        "p-valor": p_vals,
        "Significancia": 1 - p_vals
    })

    return resultados
