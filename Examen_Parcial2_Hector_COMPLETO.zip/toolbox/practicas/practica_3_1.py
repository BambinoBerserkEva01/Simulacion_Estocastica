
"""
Práctica 3.1 - Análisis de Residuos

Calcula e interpreta residuos, residuos estandarizados y studentizados para regresión múltiple.
Incluye visualización de los residuos respecto a los regresores.

Autor: Rodriguez Garcia Emiliano
"""

import numpy as np
import matplotlib.pyplot as plt

def analizar_residuos(X, Y):
    """
    Ajusta un modelo de regresión múltiple y analiza los residuos.

    Args:
        X (ndarray): Matriz de predictores (n x m)
        Y (ndarray): Vector objetivo (n)

    Returns:
        dict: Diccionario con residuos, residuos estandarizados y studentizados
    """
    # Añadir columna de unos (intercepto)
    X_aug = np.column_stack([np.ones(X.shape[0]), X])

    # Estimadores por mínimos cuadrados
    beta = np.linalg.inv(X_aug.T @ X_aug) @ X_aug.T @ Y
    Y_pred = X_aug @ beta
    e = Y - Y_pred

    n = len(Y)
    m = X.shape[1]
    SSres = np.sum(e ** 2)
    MSres = SSres / (n - m - 1)
    print(f"MSres: {MSres:.4f}")

    # Residuos estandarizados
    e_std = e / np.sqrt(MSres)

    # Residuos studentizados
    H = X_aug @ np.linalg.inv(X_aug.T @ X_aug) @ X_aug.T
    hii = np.diag(H)
    e_stud = e / np.sqrt(MSres * (1 - hii))

    # Graficar residuos vs primer predictor
    plt.figure(figsize=(14, 5))
    plt.subplot(1, 2, 1)
    plt.scatter(X[:, 0], e_std)
    plt.axhline(0, color='gray', linestyle='--')
    plt.title("Residuos estandarizados vs X1")
    plt.xlabel("X1")
    plt.ylabel("Residuos estandarizados")

    plt.subplot(1, 2, 2)
    plt.hist(e_stud, bins=10, edgecolor='black')
    plt.title("Histograma de residuos studentizados")
    plt.xlabel("Residuo")
    plt.ylabel("Frecuencia")

    plt.tight_layout()
    plt.show()

    return {
        "residuos": e,
        "estandarizados": e_std,
        "studentizados": e_stud,
        "MSres": MSres
    }
