
"""
Comparación de Modelos de Regresión con Diferentes Subconjuntos de Variables

Evalúa R² y AIC de múltiples modelos definidos por subconjuntos de variables.

Autor: Héctor Madera
"""

import numpy as np
import pandas as pd
import statsmodels.api as sm

def comparar_modelos(X, Y, subconjuntos, nombres_vars=None):
    """
    Ajusta modelos con distintos subconjuntos de predictores y compara métricas.

    Args:
        X (ndarray): Matriz de predictores (n x m)
        Y (ndarray): Vector de respuesta
        subconjuntos (list): Lista de listas con índices de columnas a usar
        nombres_vars (list): Nombres opcionales de las variables

    Returns:
        pd.DataFrame: Tabla con R², AIC y predictores usados
    """
    resultados = []

    nombres_vars = nombres_vars or [f"X{i+1}" for i in range(X.shape[1])]

    for indices in subconjuntos:
        X_sub = sm.add_constant(X[:, indices])
        modelo = sm.OLS(Y, X_sub).fit()
        etiquetas = [nombres_vars[i] for i in indices]
        resultados.append({
            "Predictores": etiquetas,
            "R²": modelo.rsquared,
            "AIC": modelo.aic
        })

    return pd.DataFrame(resultados)
