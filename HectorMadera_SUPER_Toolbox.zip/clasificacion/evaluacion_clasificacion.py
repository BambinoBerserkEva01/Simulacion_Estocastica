
"""
Evaluación de Modelos de Clasificación Binaria

Calcula precisión, matriz de confusión y exactitud usando sklearn.

Autor: Héctor Madera
"""

from sklearn.metrics import confusion_matrix, accuracy_score, classification_report

def evaluar_clasificacion(y_true, y_pred):
    """
    Evalúa modelo binario.

    Args:
        y_true (array): Valores verdaderos
        y_pred (array): Predicciones binarias

    Returns:
        dict: matriz de confusión, exactitud, resumen
    """
    matriz = confusion_matrix(y_true, y_pred)
    exactitud = accuracy_score(y_true, y_pred)
    resumen = classification_report(y_true, y_pred)

    print("Matriz de Confusión:")
    print(matriz)
    print(f"\nExactitud: {exactitud:.4f}")
    print("\nReporte:")
    print(resumen)

    return {
        "matriz_confusion": matriz,
        "accuracy": exactitud,
        "reporte": resumen
    }
