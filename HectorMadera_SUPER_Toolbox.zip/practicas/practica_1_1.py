
"""
Práctica 1.1 - Análisis de Regresión Lineal

Contiene conjuntos de datos en formato NumPy array, representando posibles variables dependientes
para aplicar regresión lineal en ejercicios básicos.

Autor: Rodriguez Garcia Emiliano
Fecha: 20/08/2024
"""

import numpy as np

# Variables dependientes
Y1 = np.array([4, 8, 2, 2, 10, 0, 1, 3, 4, 2, 2, 0, 8, 2, 8])
Y2 = np.array([6, 7, 4, 3, 7, 3, 1, 0, 3, 4, 4, 0, 8, 1, 9])
Y3 = np.array([7, 10, 2, 4, 8, 0, 0, 3, 2, 4, 2, 0, 10, 2, 6])
Y4 = np.array([6, 8, 1, 6, 8, 1, 1, 0, 4, 5, 0, -1, 5, 0, 9])
Y5 = np.array([5, 9, 2, 3, 9, 0, 1, 1, 4, 4, 4, 0, 9, 2, 9])
Y6 = np.array([7, 8, 0, 4, 7, 4, 0, 3, 2, 2, 4, 0, 10, -1, 7])
Y7 = np.array([5, 9, 2, 4, 8, 3, -1, 2, 6, 4, 3, 0, 6, 0, 5])

def get_dataset():
    """
    Devuelve un diccionario con todos los conjuntos de datos disponibles.

    Returns:
        dict: Diccionario con claves 'Y1' a 'Y7' y sus respectivos arrays.
    """
    return {
        "Y1": Y1,
        "Y2": Y2,
        "Y3": Y3,
        "Y4": Y4,
        "Y5": Y5,
        "Y6": Y6,
        "Y7": Y7
    }
