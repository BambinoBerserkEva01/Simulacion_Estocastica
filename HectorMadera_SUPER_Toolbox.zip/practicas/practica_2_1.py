
"""
Práctica 2.1 - Regresión Lineal Múltiple

Se utilizan tres variables predictoras (X1, X2, X3) para predecir la variable respuesta Y.
Se ajusta un modelo de regresión múltiple y se presentan los coeficientes estimados.

Autor: Rodriguez Garcia Emiliano
"""

import numpy as np
from sklearn.linear_model import LinearRegression

# Datos de entrada (40 muestras)
X = np.array([
    [5.39, 7.23, 7.32], [8.58, 5.20, 5.57], [8.82, 7.18, 9.48], [6.24, 9.26, 6.54], [9.49, 5.82, 6.27],
    [6.13, 8.84, 5.96], [5.65, 9.48, 8.15], [5.09, 9.40, 8.84], [8.96, 8.60, 6.76], [7.09, 9.40, 6.84],
    [7.28, 9.54, 9.65], [9.73, 9.16, 7.15], [9.69, 6.21, 8.83], [9.47, 6.54, 9.12], [7.22, 5.84, 9.12],
    [9.66, 9.87, 8.22], [8.29, 8.43, 5.91], [9.28, 7.75, 8.37], [9.76, 7.35, 9.98], [6.02, 5.99, 6.36],
    [7.12, 5.24, 8.61], [6.44, 6.35, 8.45], [6.88, 5.16, 8.93], [8.94, 5.59, 7.99], [7.61, 7.89, 8.66],
    [9.85, 9.13, 6.43], [9.43, 6.59, 7.80], [6.94, 5.29, 6.28], [8.84, 6.88, 9.53], [6.58, 7.74, 9.19],
    [9.40, 6.92, 5.79], [7.54, 8.64, 6.21], [5.63, 7.60, 7.82], [6.27, 8.48, 6.20], [7.51, 5.14, 6.66],
    [8.70, 6.65, 6.95], [7.23, 5.57, 6.11], [8.99, 5.90, 8.17], [5.52, 7.74, 9.42], [5.12, 5.61, 9.28]
])

Y = np.array([
    3.55, 6.39, 4.97, 2.55, 4.14, 0.27, 1.31, 3.23, 3.66, 2.43,
    3.75, 4.91, 5.95, 3.52, 4.08, 3.57, 3.31, 5.48, 4.59, 4.85,
    5.64, 2.82, 5.08, 3.44, 3.47, 4.43, 5.18, 4.00, 6.10, 5.92,
    4.52, 0.90, 3.65, 1.66, 2.89, 4.96, 2.32, 6.79, 2.89, 2.31
])

def ajustar_regresion_multiple():
    """
    Ajusta un modelo de regresión lineal múltiple y muestra los coeficientes.

    Returns:
        model (LinearRegression): Modelo entrenado.
    """
    model = LinearRegression()
    model.fit(X, Y)

    print("Intercepto (β0):", model.intercept_)
    print("Coeficientes (β1, β2, β3):", model.coef_)

    return model
