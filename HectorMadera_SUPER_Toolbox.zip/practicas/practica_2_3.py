
"""
Práctica 2.3 - Selección hacia delante (Forward Selection)

Implementa un algoritmo simple para selección progresiva de variables predictoras
basado en R² (coeficiente de determinación) con modelos de regresión lineal.

Autor: Rodriguez Garcia Emiliano
"""

import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score

def seleccion_hacia_adelante(X, y, nombres_vars=None, verbose=True):
    """
    Selección hacia delante de variables predictoras.

    Args:
        X (np.ndarray): Matriz de características (n_samples, n_features).
        y (np.ndarray): Vector objetivo.
        nombres_vars (list): Nombres opcionales de las variables.
        verbose (bool): Imprimir pasos del proceso.

    Returns:
        list: Índices de variables seleccionadas.
    """
    n, m = X.shape
    disponibles = list(range(m))
    seleccionadas = []
    mejor_r2 = 0

    if nombres_vars is None:
        nombres_vars = [f"X{i+1}" for i in range(m)]

    while disponibles:
        mejor_score = mejor_r2
        mejor_variable = None

        for i in disponibles:
            candidatos = seleccionadas + [i]
            modelo = LinearRegression().fit(X[:, candidatos], y)
            r2 = r2_score(y, modelo.predict(X[:, candidatos]))
            if r2 > mejor_score:
                mejor_score = r2
                mejor_variable = i

        if mejor_variable is not None:
            seleccionadas.append(mejor_variable)
            disponibles.remove(mejor_variable)
            mejor_r2 = mejor_score
            if verbose:
                print(f"Seleccionada: {nombres_vars[mejor_variable]} - R²: {mejor_r2:.4f}")
        else:
            break

    return seleccionadas
