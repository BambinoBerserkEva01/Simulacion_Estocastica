
"""
Práctica 3.2 - Regresión con Variable Categórica

Ajusta un modelo de regresión lineal utilizando una variable categórica codificada con dummies.

Autor: Rodriguez Garcia Emiliano
"""

import pandas as pd
import statsmodels.api as sm

def ajustar_regresion_categorica(df, target_col, cat_col):
    """
    Ajusta un modelo de regresión lineal con una variable categórica.

    Args:
        df (DataFrame): Datos de entrada.
        target_col (str): Nombre de la columna objetivo (Y).
        cat_col (str): Nombre de la columna categórica (X).

    Returns:
        model (OLS): Modelo ajustado con statsmodels.
    """
    X = pd.get_dummies(df[cat_col], drop_first=True)
    y = df[target_col]

    X_const = sm.add_constant(X)
    modelo = sm.OLS(y, X_const).fit()

    print(modelo.summary())
    return modelo
