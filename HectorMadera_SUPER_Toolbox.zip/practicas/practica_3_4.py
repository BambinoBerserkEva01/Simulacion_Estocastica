
"""
Práctica 3.4 - Validación de Supuestos del Modelo de Regresión

Evalúa la homoscedasticidad y normalidad de los residuales de un modelo de regresión lineal.
Incluye gráficos de dispersión, histogramas y QQ plot.

Autor: Rodriguez Garcia Emiliano
"""

import numpy as np
import matplotlib.pyplot as plt
import statsmodels.api as sm
import seaborn as sns
from scipy.stats import probplot

def validar_supuestos(X, y):
    """
    Ajusta modelo de regresión y evalúa supuestos: homoscedasticidad y normalidad.

    Args:
        X (ndarray): Variables independientes (n x m)
        y (ndarray): Variable dependiente (n)

    Returns:
        model: Modelo statsmodels ajustado
    """
    X_const = sm.add_constant(X)
    model = sm.OLS(y, X_const).fit()
    resid = model.resid
    fitted = model.fittedvalues

    print(model.summary())

    # Gráficos de residuales vs predictores
    fig, axs = plt.subplots(1, X.shape[1], figsize=(16, 4))
    for i in range(X.shape[1]):
        axs[i].scatter(X[:, i], resid)
        axs[i].axhline(0, color='gray', linestyle='--')
        axs[i].set_xlabel(f'X{i+1}')
        axs[i].set_ylabel('Residuales')
        axs[i].set_title(f'Residuales vs X{i+1}')
    plt.tight_layout()
    plt.show()

    # Histograma + KDE de los residuales
    plt.figure(figsize=(6, 4))
    sns.histplot(resid, kde=True)
    plt.title("Distribución de residuales")
    plt.xlabel("Residuales")
    plt.show()

    # QQ plot para normalidad
    plt.figure(figsize=(6, 4))
    probplot(resid, dist="norm", plot=plt)
    plt.title("QQ Plot de Residuales")
    plt.show()

    return model
