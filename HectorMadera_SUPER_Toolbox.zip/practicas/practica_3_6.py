
"""
Práctica 3.6 - Ajuste de Modelo No Lineal

Se ajusta una función no lineal a los datos usando scipy.optimize.curve_fit.
Permite trabajar con modelos de tipo logístico, exponencial, mantenimiento, etc.

Autor: Rodriguez Garcia Emiliano
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

def ajustar_modelo_no_lineal(X, y, modelo_funcion, b0, graficar=True):
    """
    Ajusta un modelo no lineal definido por el usuario a los datos.

    Args:
        X (ndarray): Variable independiente (n muestras x 1).
        y (ndarray): Variable dependiente.
        modelo_funcion (callable): Función no lineal f(x, b1, b2, ...)
        b0 (list): Aproximación inicial de parámetros.
        graficar (bool): Mostrar la curva ajustada si X es 1D.

    Returns:
        popt (ndarray): Parámetros óptimos ajustados.
        pcov (ndarray): Matriz de covarianza de los parámetros.
    """
    popt, pcov = curve_fit(modelo_funcion, X.ravel(), y, p0=b0)
    print("Parámetros ajustados:")
    for i, p in enumerate(popt):
        print(f"b{i} = {p:.4f}")

    if graficar and X.shape[1] == 1:
        x_range = np.linspace(X.min(), X.max(), 200).reshape(-1, 1)
        y_pred = modelo_funcion(x_range.ravel(), *popt)

        plt.scatter(X, y, label='Datos')
        plt.plot(x_range, y_pred, color='red', label='Modelo No Lineal')
        plt.title("Ajuste de Modelo No Lineal")
        plt.xlabel("X")
        plt.ylabel("Y")
        plt.legend()
        plt.grid(True)
        plt.show()

    return popt, pcov
