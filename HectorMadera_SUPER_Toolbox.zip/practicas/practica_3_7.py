
"""
Práctica 3.7 - Modelo Exponencial

Ajusta un modelo de la forma Y = a * exp(b * X) utilizando mínimos cuadrados no lineales.

Autor: Rodriguez Garcia Emiliano
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

def modelo_exponencial(x, a, b):
    return a * np.exp(b * x)

def ajustar_modelo_exponencial(X, y, b0=(1.0, -0.1), graficar=True):
    """
    Ajusta un modelo exponencial Y = a * exp(b * X) a los datos dados.

    Args:
        X (ndarray): Variable independiente (n x 1).
        y (ndarray): Variable dependiente.
        b0 (tuple): Valores iniciales (a, b).
        graficar (bool): Mostrar curva ajustada.

    Returns:
        popt (ndarray): Parámetros óptimos ajustados.
        pcov (ndarray): Matriz de covarianza.
    """
    popt, pcov = curve_fit(modelo_exponencial, X.ravel(), y, p0=b0)
    a, b = popt
    print(f"Modelo ajustado: Y = {a:.4f} * exp({b:.4f} * X)")

    if graficar:
        x_range = np.linspace(X.min(), X.max(), 200)
        y_pred = modelo_exponencial(x_range, *popt)

        plt.scatter(X, y, label='Datos', color='blue')
        plt.plot(x_range, y_pred, label='Ajuste exponencial', color='red')
        plt.title("Ajuste de Modelo Exponencial")
        plt.xlabel("X")
        plt.ylabel("Y")
        plt.legend()
        plt.grid(True)
        plt.show()

    return popt, pcov
