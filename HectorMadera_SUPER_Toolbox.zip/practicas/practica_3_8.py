
"""
Práctica 3.8 - Modelo Logarítmico No Lineal

Ajusta un modelo de la forma: Y = b1 + b2 * log(b3 * X + b4)

Autor: Rodriguez Garcia Emiliano
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

def modelo_logaritmico(X, b1, b2, b3, b4):
    return b1 + b2 * np.log(b3 * X + b4)

def ajustar_modelo_logaritmico(X, y, b0=(1, 1, 1, 1), graficar=True):
    """
    Ajusta un modelo logarítmico Y = b1 + b2 * log(b3 * X + b4)

    Args:
        X (ndarray): Variable independiente (n x 1).
        y (ndarray): Variable dependiente.
        b0 (tuple): Valores iniciales (b1, b2, b3, b4).
        graficar (bool): Mostrar gráfico de ajuste.

    Returns:
        popt (ndarray): Parámetros óptimos ajustados.
        pcov (ndarray): Matriz de covarianza.
    """
    popt, pcov = curve_fit(modelo_logaritmico, X.ravel(), y, p0=b0, maxfev=5000)
    print("Parámetros ajustados:")
    for i, p in enumerate(popt):
        print(f"b{i+1} = {p:.4f}")

    if graficar:
        x_range = np.linspace(X.min(), X.max(), 200)
        y_pred = modelo_logaritmico(x_range, *popt)

        plt.scatter(X, y, label='Datos', color='blue')
        plt.plot(x_range, y_pred, label='Ajuste logarítmico', color='orange')
        plt.title("Ajuste de Modelo Logarítmico")
        plt.xlabel("X")
        plt.ylabel("Y")
        plt.legend()
        plt.grid(True)
        plt.show()

    return popt, pcov
