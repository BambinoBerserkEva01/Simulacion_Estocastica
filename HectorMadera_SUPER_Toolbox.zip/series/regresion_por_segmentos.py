
"""
Regresión Lineal por Segmentos

Ajusta múltiples regresiones lineales a distintos rangos (tramos) de X.

Autor: Héctor Madera
"""

import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

def regresion_por_segmentos(X, Y, segmentos, verbose=True):
    """
    Ajusta regresiones lineales a segmentos definidos por rangos de X.

    Args:
        X (ndarray): Vector de entrada (n,)
        Y (ndarray): Vector de salida (n,)
        segmentos (list): Lista de tuplas (min, max) para definir tramos
        verbose (bool): Mostrar gráficas y coeficientes

    Returns:
        list: modelos por segmento
    """
    modelos = []
    X = np.asarray(X).reshape(-1)
    Y = np.asarray(Y).reshape(-1)

    plt.figure(figsize=(10, 5))
    plt.scatter(X, Y, label="Datos", alpha=0.5)

    for (a, b) in segmentos:
        idx = np.where((X >= a) & (X <= b))[0]
        x_seg = X[idx].reshape(-1, 1)
        y_seg = Y[idx]

        modelo = LinearRegression().fit(x_seg, y_seg)
        y_pred = modelo.predict(x_seg)

        if verbose:
            print(f"Segmento [{a}, {b}]: β0 = {modelo.intercept_:.2f}, β1 = {modelo.coef_[0]:.2f}")

        plt.plot(x_seg, y_pred, label=f"{a}-{b}")

        modelos.append(modelo)

    plt.title("Regresión por Segmentos")
    plt.xlabel("X")
    plt.ylabel("Y")
    plt.legend()
    plt.grid(True)
    plt.show()

    return modelos
