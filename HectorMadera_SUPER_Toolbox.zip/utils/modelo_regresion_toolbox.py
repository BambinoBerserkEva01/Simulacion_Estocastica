
"""
Caja de Herramientas - Análisis Automatizado de Modelos de Regresión

Este módulo combina todo el proceso para ajustar, validar y analizar
modelos de regresión lineal (simple o múltiple).

Autor: Rodriguez Garcia Emiliano
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.api as sm
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
from scipy import stats
from numpy.linalg import inv

def analizar_modelo(X, Y, alpha=0.05, verbose=True):
    """
    Realiza análisis completo de regresión:
    - Ajuste del modelo
    - Significancia global e individual
    - Homocedasticidad y residuos
    - Intervalos de confianza
    - Validación de supuestos

    Args:
        X (ndarray): Matriz de predictores
        Y (ndarray): Vector de respuesta
        alpha (float): Nivel de significancia (por defecto 0.05)
        verbose (bool): Mostrar o no gráficos e impresión

    Returns:
        dict: Resumen del análisis (coef, R², residuos, p-valores, ICs)
    """
    n, m = X.shape
    X_aug = np.column_stack([np.ones(n), X])
    beta = inv(X_aug.T @ X_aug) @ X_aug.T @ Y
    y_pred = X_aug @ beta
    e = Y - y_pred
    MSres = np.sum(e**2) / (n - m - 1)

    # Coeficientes e intervalos
    var_b = MSres * inv(X_aug.T @ X_aug)
    se = np.sqrt(np.diag(var_b))
    t_val = stats.t.ppf(1 - alpha / 2, df=n - m - 1)
    ICs = [(beta[i] - t_val * se[i], beta[i] + t_val * se[i]) for i in range(len(beta))]

    # F-test global
    SSr = np.sum((y_pred - np.mean(Y)) ** 2)
    SSres = np.sum((Y - y_pred) ** 2)
    MSr = SSr / m
    F0 = MSr / MSres
    p_model = stats.f.sf(F0, m, n - m - 1)

    # t-tests individuales
    t_vals = np.abs(beta / se)
    p_vals = 2 * stats.t.sf(t_vals, n - m - 1)

    # Validación visual
    if verbose:
        print("Resumen del modelo (OLS):")
        for i in range(len(beta)):
            nombre = "Intercepto" if i == 0 else f"X{i}"
            print(f"{nombre}: β = {beta[i]:.4f}, t = {t_vals[i]:.4f}, p = {p_vals[i]:.4f}, IC = [{ICs[i][0]:.4f}, {ICs[i][1]:.4f}]")
        print(f"R² = {r2_score(Y, y_pred):.4f}")
        print(f"F0 = {F0:.4f}, p-modelo = {p_model:.4f}")

        # Gráficos
        fig, axs = plt.subplots(1, 2, figsize=(12, 4))
        axs[0].scatter(y_pred, e)
        axs[0].axhline(0, color='gray', linestyle='--')
        axs[0].set_title("Residuos vs Predicción")
        axs[0].set_xlabel("Y predicho")
        axs[0].set_ylabel("Residuales")

        sns.histplot(e, kde=True, ax=axs[1])
        axs[1].set_title("Distribución de Residuos")
        plt.tight_layout()
        plt.show()

        # QQ plot
        sm.qqplot(e, line='s')
        plt.title("QQ Plot de residuos")
        plt.grid(True)
        plt.show()

    return {
        "coeficientes": beta,
        "r2": r2_score(Y, y_pred),
        "residuos": e,
        "p_modelo": p_model,
        "p_valores": p_vals,
        "ICs": ICs
    }
