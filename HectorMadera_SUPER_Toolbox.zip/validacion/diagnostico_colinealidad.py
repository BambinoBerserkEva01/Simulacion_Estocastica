
"""
Diagnóstico de Multicolinealidad

Calcula matriz de correlación y VIF (Variance Inflation Factor) para evaluar colinealidad entre predictores.

Autor: Héctor Madera
"""

import numpy as np
import pandas as pd
from statsmodels.stats.outliers_influence import variance_inflation_factor

def matriz_correlacion(X, nombres_vars=None):
    """
    Calcula la matriz de correlación entre variables.

    Args:
        X (ndarray): Matriz de predictores (n x m)
        nombres_vars (list): Nombres opcionales de las variables

    Returns:
        DataFrame: Matriz de correlación
    """
    df = pd.DataFrame(X, columns=nombres_vars or [f"X{i+1}" for i in range(X.shape[1])])
    return df.corr()

def calcular_vif(X, nombres_vars=None):
    """
    Calcula el VIF (Variance Inflation Factor) para cada variable.

    Args:
        X (ndarray): Matriz de predictores (n x m)
        nombres_vars (list): Lista de nombres opcionales

    Returns:
        DataFrame: Tabla con variables y su VIF
    """
    nombres = nombres_vars or [f"X{i+1}" for i in range(X.shape[1])]
    vif_data = {
        "Variable": nombres,
        "VIF": [variance_inflation_factor(X, i) for i in range(X.shape[1])]
    }
    return pd.DataFrame(vif_data)
